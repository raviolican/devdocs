
//{block name="backend/index/application"}
//{$smarty.block.parent}

//{include file="backend/index/swag_last_registrations/model/account.js"}
//{include file="backend/index/swag_last_registrations/store/account.js"}
//{include file="backend/index/swag_last_registrations/view/main.js"}

//{/block}